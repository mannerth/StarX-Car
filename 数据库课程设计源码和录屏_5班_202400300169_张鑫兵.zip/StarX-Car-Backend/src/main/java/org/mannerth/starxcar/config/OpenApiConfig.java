package org.mannerth.starxcar.config;

import org.mannerth.starxcar.car.domain.Car;
import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;






@Configuration
public class OpenApiConfig {

    @Bean
    OpenAPI starXCarOpenApi() {
        return new OpenAPI()
                .info(new Info().title("StarX-Car API").version("v1").description("网约车后端接口文档"))
                .components(new Components().addSecuritySchemes("bearerAuth", new SecurityScheme()
                        .type(SecurityScheme.Type.HTTP)
                        .scheme("bearer")
                        .bearerFormat("JWT")));
    }
}