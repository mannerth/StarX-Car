package org.mannerth.starxcar.order.application;

import org.mannerth.starxcar.auth.domain.User;
import org.mannerth.starxcar.auth.infrastructure.UserMapper;
import org.mannerth.starxcar.config.ReservationProperties;
import org.mannerth.starxcar.infrastructure.amap.AmapRouteClient;
import org.mannerth.starxcar.infrastructure.amap.Gcj02Coordinate;
import org.mannerth.starxcar.infrastructure.amap.RouteEstimate;
import org.mannerth.starxcar.order.domain.OrderEventType;
import org.mannerth.starxcar.order.domain.OrderOperatorType;
import org.mannerth.starxcar.order.domain.OrderStatus;
import org.mannerth.starxcar.order.domain.OrderType;
import org.mannerth.starxcar.order.domain.RideOrder;
import org.mannerth.starxcar.order.domain.RideOrderEvent;
import org.mannerth.starxcar.order.infrastructure.RideOrderEventMapper;
import org.mannerth.starxcar.order.infrastructure.RideOrderMapper;
import org.mannerth.starxcar.order.pricing.application.PricingRuleService;
import org.mannerth.starxcar.order.pricing.domain.FareCalculation;
import org.mannerth.starxcar.order.pricing.domain.FareCalculator;
import org.mannerth.starxcar.order.pricing.domain.PricingRuleDefinition;
import org.mannerth.starxcar.order.request.OrderQuoteRequest;
import org.mannerth.starxcar.order.request.PlaceRequest;
import org.mannerth.starxcar.order.response.FareQuoteResponse;
import org.mannerth.starxcar.order.response.OrderCreatedResponse;
import org.mannerth.starxcar.order.response.OrderQuoteResponse;
import org.mannerth.starxcar.passenger.domain.Passenger;
import org.mannerth.starxcar.passenger.infrastructure.PassengerMapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;






@Service
public class OrderServiceImpl implements OrderService {
    private static final List<OrderStatus> UNFINISHED_STATUSES = List.of(
            OrderStatus.PENDING, OrderStatus.ACCEPTED, OrderStatus.DRIVER_ARRIVED, OrderStatus.IN_SERVICE);
    private static final List<OrderStatus> ACTIVE_RESERVATION_STATUSES = List.of(OrderStatus.SCHEDULED, OrderStatus.PENDING);
    private static final ZoneId BUSINESS_ZONE = ZoneId.of("Asia/Shanghai");

    private final PassengerMapper passengerMapper;
    private final UserMapper userMapper;
    private final RideOrderMapper rideOrderMapper;
    private final RideOrderEventMapper rideOrderEventMapper;
    private final PricingRuleService pricingRuleService;
    private final FareCalculator fareCalculator;
    private final AmapRouteClient amapRouteClient;
    private final OrderNumberGenerator orderNumberGenerator;
    private final ReservationProperties reservationProperties;
    private final Clock clock;

    public OrderServiceImpl(PassengerMapper passengerMapper, UserMapper userMapper, RideOrderMapper rideOrderMapper,
                            RideOrderEventMapper rideOrderEventMapper, PricingRuleService pricingRuleService,
                            FareCalculator fareCalculator, AmapRouteClient amapRouteClient,
                            OrderNumberGenerator orderNumberGenerator, ReservationProperties reservationProperties,
                            Clock clock) {
        this.passengerMapper = passengerMapper;
        this.userMapper = userMapper;
        this.rideOrderMapper = rideOrderMapper;
        this.rideOrderEventMapper = rideOrderEventMapper;
        this.pricingRuleService = pricingRuleService;
        this.fareCalculator = fareCalculator;
        this.amapRouteClient = amapRouteClient;
        this.orderNumberGenerator = orderNumberGenerator;
        this.reservationProperties = reservationProperties;
        this.clock = clock;
    }

    @Override
    public OrderQuoteResponse quote(OrderQuoteRequest request) {
        validateOrderType(request);
        return calculateQuote(request);
    }

    @Override
    @Transactional
    public OrderCreatedResponse create(Long passengerId, OrderQuoteRequest request) {
        Passenger passenger = passengerMapper.lockById(passengerId);
        if (passenger == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "乘客不存在");
        }
        requireActivePassenger(passengerId);
        validateOrderType(request);
        if (request.orderType() == OrderType.SCHEDULED) {
            long reservationCount = rideOrderMapper.selectCount(Wrappers.<RideOrder>lambdaQuery()
                    .eq(RideOrder::getPassengerId, passengerId)
                    .eq(RideOrder::getOrderType, OrderType.SCHEDULED)
                    .in(RideOrder::getStatus, ACTIVE_RESERVATION_STATUSES));
            if (reservationCount > 0) {
                throw new ResponseStatusException(HttpStatus.CONFLICT, "当前存在未结束的预约订单");
            }
        } else {
            long unfinishedCount = rideOrderMapper.selectCount(Wrappers.<RideOrder>lambdaQuery()
                    .eq(RideOrder::getPassengerId, passengerId)
                    .in(RideOrder::getStatus, UNFINISHED_STATUSES));
            if (unfinishedCount > 0) {
                throw new ResponseStatusException(HttpStatus.CONFLICT, "当前存在未结束订单");
            }
        }

        OrderQuoteResponse quote = calculateQuote(request);
        RideOrder order = buildOrder(passengerId, request, quote);
        if (rideOrderMapper.insert(order) != 1 || order.getId() == null) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "订单创建失败");
        }
        RideOrderEvent event = new RideOrderEvent();
        event.setOrderId(order.getId());
        event.setEventType(OrderEventType.CREATE);
        event.setToStatus(order.getStatus());
        event.setOperatorType(OrderOperatorType.passenger);
        event.setOperatorId(passengerId);
        event.setCreatedTime(now());
        rideOrderEventMapper.insert(event);
        return new OrderCreatedResponse(order.getOrderNo(), order.getStatus(), quote);
    }

    private void validateOrderType(OrderQuoteRequest request) {
        if (request.orderType() == OrderType.INSTANT) {
            if (request.scheduledPickupTime() != null) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "即时单不能指定预约上车时间");
            }
        } else {
            validateReservationTime(request.scheduledPickupTime());
        }
    }

    private void validateReservationTime(LocalDateTime scheduledPickupTime) {
        if (scheduledPickupTime == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "预约单必须指定预约上车时间");
        }
        LocalDateTime now = now();
        LocalDateTime earliest = now.plusMinutes(reservationProperties.getMinLeadMinutes());
        LocalDateTime latest = now.plusDays(reservationProperties.getMaxAdvanceDays());
        if (scheduledPickupTime.isBefore(earliest)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "预约时间必须晚于当前时间至少 " + reservationProperties.getMinLeadMinutes() + " 分钟");
        }
        if (scheduledPickupTime.isAfter(latest)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "预约时间不能超过当前时间 " + reservationProperties.getMaxAdvanceDays() + " 天");
        }
    }

    private OrderQuoteResponse calculateQuote(OrderQuoteRequest request) {
        PricingRuleDefinition rule = pricingRuleService.getDefaultActiveRule();
        RouteEstimate route = amapRouteClient.estimateDrivingRoute(toCoordinate(request.pickup()),
                toCoordinate(request.destination()));
        FareCalculation fare = fareCalculator.calculate(rule, route.distanceM(), route.durationS(), 0);
        return new OrderQuoteResponse(rule.id(), rule.version(), route.distanceM(), route.durationS(), toFare(fare),
                request.orderType(), request.scheduledPickupTime());
    }

    private RideOrder buildOrder(Long passengerId, OrderQuoteRequest request, OrderQuoteResponse quote) {
        RideOrder order = new RideOrder();
        order.setOrderNo(orderNumberGenerator.next());
        order.setOrderType(request.orderType());
        order.setPassengerId(passengerId);
        order.setPricingRuleId(quote.pricingRuleId());
        order.setPricingRuleVersion(quote.pricingRuleVersion());
        boolean scheduled = request.orderType() == OrderType.SCHEDULED;
        order.setStatus(scheduled ? OrderStatus.SCHEDULED : OrderStatus.PENDING);
        order.setVersion(0L);
        order.setPaymentStatus("unpaid");
        copyPickup(order, request.pickup());
        copyDestination(order, request.destination());
        if (scheduled) {
            order.setScheduledPickupTime(request.scheduledPickupTime());
        }
        order.setEstimatedDistanceM(quote.estimatedDistanceM());
        order.setEstimatedDurationS(quote.estimatedDurationS());
        order.setBillingDistanceM(quote.estimatedDistanceM());
        order.setBaseFare(quote.fare().baseFare());
        order.setDistanceFare(quote.fare().distanceFare());
        order.setDrivingTimeFare(quote.fare().drivingTimeFare());
        order.setWaitingFare(quote.fare().waitingFare());
        order.setTotalFare(quote.fare().totalFare());
        order.setCreatedTime(now());
        order.setDispatchTime(scheduled ? null : order.getCreatedTime());
        return order;
    }

    private void requireActivePassenger(Long passengerId) {
        User user = userMapper.selectById(passengerId);
        if (user == null || !"active".equals(user.getStatus())) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "账号已停用或注销");
        }
    }

    private void copyPickup(RideOrder order, PlaceRequest place) {
        order.setPickupPoiId(place.poiId());
        order.setPickupName(place.name().trim());
        order.setPickupAddress(place.address());
        order.setPickupLat(place.latitude());
        order.setPickupLng(place.longitude());
    }

    private void copyDestination(RideOrder order, PlaceRequest place) {
        order.setDestinationPoiId(place.poiId());
        order.setDestinationName(place.name().trim());
        order.setDestinationAddress(place.address());
        order.setDestinationLat(place.latitude());
        order.setDestinationLng(place.longitude());
    }

    private Gcj02Coordinate toCoordinate(PlaceRequest place) {
        return new Gcj02Coordinate(place.latitude().doubleValue(), place.longitude().doubleValue());
    }

    private FareQuoteResponse toFare(FareCalculation fare) {
        return new FareQuoteResponse(fare.baseFare(), fare.distanceFare(), fare.drivingTimeFare(), fare.waitingFare(),
                fare.totalFare());
    }

    private LocalDateTime now() {
        return LocalDateTime.ofInstant(Instant.now(clock), BUSINESS_ZONE).withNano(0);
    }
}