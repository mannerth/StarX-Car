package org.mannerth.starxcar.order.rating.infrastructure;

import org.mannerth.starxcar.order.rating.domain.OrderRating;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;






@Mapper
public interface OrderRatingMapper extends BaseMapper<OrderRating> {
}