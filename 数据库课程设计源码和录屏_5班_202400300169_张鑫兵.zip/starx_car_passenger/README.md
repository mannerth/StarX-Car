# StarX-Car 乘客端

`starx_car_passenger` 是 StarX-Car 的乘客 Android App，依赖本地 `starx_car_common` 提供会话、网络和高德地图基础能力。本阶段已完成账号、即时叫车、订单详情、司机位置推送和服务中路线展示，并在个人中心提供真实余额展示和模拟充值入口。界面使用统一的绿色 Material 3 主题，重点操作与余额信息采用清晰的信息卡层级。

## 当前状态

登录、乘客注册、会话恢复、退出、个人资料编辑与修改密码均已对接现有后端；即时叫车支持上下排列的上车地/目的地入口、首次自动定位、地点搜索、推荐路线、报价、创建、订单取消、订单列表/详情、司机位置和服务中高德驾车路线折线。乘客可在 `SCHEDULED`/`PENDING`/`ACCEPTED` 免费取消，在 `DRIVER_ARRIVED` 按订单绑定规则收取到达后取消费，在 `IN_SERVICE` 中途结束并查看服务端结算结果；完成或终止订单支持七天内提交投诉，并可在个人中心查看本人投诉的处理进度、管理员回复和退款结果。项目采用 Riverpod 管理登录态；`flutter analyze`、`flutter test` 和 Android debug APK 构建均已通过。认证 Controller 测试覆盖角色会话恢复、匹配登录保存和错误角色拒绝；Repository 契约测试覆盖报价地点序列化（含坐标精度）、状态筛选、取消原因清理和路线位置解析。

## 已实现功能

### 认证与会话

- 登录：`POST /api/auth/login`，仅接受后端返回 `passenger` 角色的账号。
- 登录提交期间保留表单内容；账号、密码或网络错误会在当前页面显示提示，不会重建页面或静默失败。
- 注册：`POST /api/auth/passengers/register`，收集用户名、密码、邮箱、真实姓名、性别、11 位手机号；注册成功后直接保存令牌并进入个人中心。
- 会话恢复：启动时从公共包的加密存储读取会话，只有乘客角色会进入已登录界面；切换账号时资料 Provider 会随会话失效并重新加载，避免展示上一账号的缓存资料。
- 退出：清除加密存储中的 access token 与 refresh token，返回认证页。
- 注销账号：二次确认后调用 `DELETE /api/passengers/me`；服务端保留乘客资料和历史行程并标记账号 `cancelled`，成功后清理本地会话且不可恢复登录。
- 请求鉴权和 401 刷新全部由公共 `ApiClient` 完成，乘客业务代码不重复管理 Token。

### 个人中心

- 查看当前用户的用户名、真实姓名、邮箱、性别和后端脱敏手机号。
- 调用 `PUT /api/users/me` 的 Multipart 资料表单修改用户名、真实姓名、邮箱和性别；从系统相册选择头像文件后与资料一次提交，由后端上传并保存头像 URL。
- 个人中心优先展示后端返回的头像 URL；未上传头像时使用用户名或真实姓名首字作为默认头像。
- 调用 `PUT /api/passengers/me` 修改手机号；手机号更新后由后端触发器维护脱敏展示值。
- 调用 `POST /api/users/me/password`，验证原密码后修改密码。
- 资料编辑与密码弹窗会等待退出动画结束后再释放输入控制器，焦点停留在输入框时保存或取消不会使用已释放的 controller。
- 展示后端安全消息；网络、认证与服务端错误不会暴露底层异常。

### 即时叫车与行程

- 登录后首次进入叫车页会先通过 common 的 `AmapPermissionService` 请求前台定位权限（区分普通拒绝与永久拒绝并提示），授权成功后再自动请求当前位置、将地图定位至当前位置，并在尚未手动选点时将其作为上车地；定位失败会明确提示，用户可通过地图右下角按钮重试，无需再手动去系统设置开启权限。
- 上车地与目的地上下排列，直接展示已选地点名；点击任一行进入独立搜索页。搜索输入采用防抖联想并随关键词动态刷新，始终在全国范围检索，有定位点时按距离排序，并展示城市、区县、地址和距离；列表滚动到底后自动继续加载下一页，失败时可单独重试。定位失败时不使用默认北京坐标干扰搜索。两点选定后立即调用高德 Android 路线 SDK，地图自动缩放至完整路线并展示推荐距离和时长。
- 本地先校验 GCJ-02 坐标系和两点不能相同，再调用 `/orders/quote`；高德坐标提交前统一保留 6 位小数，避免 POI 原始精度超过后端约束而出现“数字的值超出了允许的范围”。
- 展示起步、距离、行程时间、等待和总价五项预估费用；确认后调用 `/orders` 创建即时订单，并直接进入新建 `PENDING` 行程详情。报价和下单请求支持取消，处理中可用关闭图标终止，页面离开时也会自动取消未完成请求。
- 叫车页顶部支持「即时叫车/预约叫车」切换：预约模式需选择预约上车时间（最早当前时间后 30 分钟、最远 7 天），报价与下单携带预约时间，创建后进入「等待派单」状态；系统在预约时间前 30 分钟自动派单，派单前可免费取消，`SCHEDULED -> PENDING` 流转由行程详情WebSocket 状态订阅自动承接。
- 我的行程支持分页、状态筛选、详情时间线、状态时间和费用明细；详情通过 WebSocket 实时接收订单状态，自动从等待接单切换到接驾、行程中和完成状态；`SCHEDULED`/`PENDING`/`ACCEPTED` 可免费取消，`DRIVER_ARRIVED` 取消时由服务端按订单创建时绑定的规则收取到达后取消费。
- 行程列表首屏、刷新和分页请求绑定页面生命周期；切换筛选或离开页面会取消未完成请求，避免继续加载旧筛选结果。
- 接驾阶段通过 WebSocket 接收司机位置，并在地图上同时绘制“司机当前位置 → 上车点”驾车路线（蓝色）与“乘客当前位置 → 上车点”步行路线（橙色），显示司机预计到达分钟数、乘客步行距离/时长；地图视野以乘客步行路线为主进行缩放。司机驾车路线会在司机移动超过 50 米或间隔 3 秒时自动重规划（规划失败且暂无路线时每 5 秒自动重试），乘客步行路线仅在乘客位置明显变化（超过 100 米）或 120 秒后重规划，乘客已在上车点附近时不再绘制步行路线；司机已到达时显示“司机已到达上车点”提示。页面销毁后自动取消 WebSocket 订阅，`stale` 位置会标记为最后已知位置。
- 订单状态、位置和路线上下文请求遇到临时网络错误时按 1/2 秒有限退避重试，连续失败后提供手动重试；页面离开、后台和终态会停止任务并取消进行中的请求。
- `IN_SERVICE` 通过 common 的高德 Android 路线 SDK 规划“司机当前位置 -> 目的地”，在路线上用蓝色标记实时标注司机当前位置，地图视野跟随司机当前位置与目的地，位置每次更新后立即重绘；路线在司机移动超过 50 米或间隔 5 秒后自动以当前位置为起点重规划（规划失败且暂无路线时每 5 秒自动重试），失败时保留两个标记并提供路线重试。司机位置通过 WebSocket 推送，`stale` 位置会明确标注为最后已知位置。行程详情页内的服务中路线地图与司机位置地图均可直接拖动、缩放操控。
- 行程详情页地图信息下方展示司机与车辆信息卡：接单司机评分（星级与数值）、脱敏手机号、车牌号、车辆品牌/颜色/车型，以及「联系司机」按钮；按钮通过系统电话应用以 `tel:` 调起拨号，使用订单详情返回的司机完整手机号预填号码，仅对已接单（存在司机）的订单展示。

### 行程评价

- 订单完成后，行程详情页展示评价区：未评价时提供 1-5 星选择与可选文字（最多 500 字），调用 `POST /api/orders/{orderNo}/rating` 提交；已评价时只读展示评分、文字与提交时间。
- 评价仅对本人已完成且未超过 7 天时限的订单开放，一个订单只能评价一次；订单未完成、重复评价或超过时限由服务端返回 409，客户端以 SnackBar 展示错误提示。
- 个人中心新增「我的评价」入口，通过 `GET /api/passengers/me/ratings` 分页查看本人提交的评价（订单号、星级、文字、时间），支持下拉刷新。
- 个人中心新增「我的投诉」入口，通过 `GET /api/complaints/me` 分页查看本人投诉；列表展示投诉原因、待处理/处理中/已处理状态、管理员处理方式、文字回复、退款金额和结案时间，支持下拉刷新与继续加载。

## 工程结构

```text
lib/
  main.dart                         ProviderScope 启动入口
  app.dart                          MaterialApp、主题、会话分流
  core/providers.dart               API 地址、SessionStore、ApiClient Provider
  features/
    auth/
      auth_controller.dart          Riverpod AsyncNotifier 登录、注册、退出
      auth_page.dart                登录/注册表单
    profile/
      passenger_repository.dart     当前用户资料和密码 API
      profile_page.dart             个人中心与编辑弹窗
    booking/
      booking_page.dart              首次定位、地点搜索、推荐路线、报价和即时下单
    orders/
      passenger_order_repository.dart  报价、即时订单、位置和路线 API
      passenger_orders_page.dart        我的行程、状态/位置订阅、取消和服务中地图
      passenger_complaints_page.dart    我的投诉、处理进度与管理员回复
```

依赖方向保持为 `starx_car_passenger -> starx_car_common`。乘客页面、资料 Repository 和 Riverpod 状态只保留在本项目。

## 后端接口

| 方法 | 地址 | 用途 |
| --- | --- | --- |
| `POST` | `/api/auth/login` | 乘客账号登录 |
| `POST` | `/api/auth/passengers/register` | 创建乘客账号并返回令牌 |
| `POST` | `/api/auth/refresh` | 由公共 HTTP 层自动调用 |
| `GET` | `/api/users/me` | 获取当前基础资料 |
| `PUT` | `/api/users/me` | 修改用户名、邮箱、性别 |
| `POST` | `/api/users/me/password` | 验证原密码后修改密码 |
| `GET` / `PUT` / `DELETE` | `/api/passengers/me` | 获取、修改手机号或注销账号（保留历史记录） |
| `POST` | `/api/orders/quote` | 获取即时/预约订单预估报价 |
| `POST` | `/api/orders` | 创建即时订单或预约订单 |
| `GET` | `/api/passengers/me/orders` | 分页查询乘客行程 |
| `GET` | `/api/orders/{orderNo}` | 查询行程详情 |
| `POST` | `/api/orders/{orderNo}/cancel` | 到达前免费取消；到达后按订单绑定规则收取取消费 |
| `POST` | `/api/orders/{orderNo}/terminate` | 服务中途结束并结算 |
| `POST` | `/api/orders/{orderNo}/complaints` | 订单结束七天内提交投诉 |
| `GET` | `/api/complaints/me` | 分页查询本人投诉及管理员处理说明、退款结果 |
| `GET` | `/api/orders/{orderNo}/driver-location` | 查询司机最后位置 |
| `GET` | `/api/orders/{orderNo}/route-context` | 获取服务中路线起点和目的地 |

## Android 配置、运行与验证

- application ID：`org.mannerth.starxcar.passenger`。
- 跨角色接口字段、状态机、错误码和坐标约定见仓库根目录的 [`docs/client-api-contract.md`](../docs/client-api-contract.md)。
- 默认 API 地址：`http://10.0.2.2:8080/api`，适用于 Android 模拟器访问本机后端；也可用 `--dart-define=API_BASE_URL=http://<host>:<port>/api` 覆盖。
- 高德 Android Key 配置在本项目 `android/amap.properties` 的 `AMAP_ANDROID_KEY`；该文件已忽略且不能提交。`--dart-define` 只用于 API 地址，不能替代原生清单 Key。
- Android 主清单已声明高德地图和一次性前台定位需要的网络、网络状态、Wi-Fi 状态、粗略/精确位置与 A-GPS 权限，并注册独立的 `APSService` 定位服务；这些配置同时适用于 debug 和 release 构建，不申请后台定位。
- 为本地 HTTP 开发已允许 Android 明文流量；部署环境必须使用 HTTPS。
- 因工程位于 D 盘、Flutter Pub 缓存位于 C 盘，已关闭 Kotlin 增量编译并使用进程内编译，避免 `image_picker_android` 的跨盘缓存错误；首次 Android 构建会稍慢。
- Gradle 插件与 Android 依赖解析优先使用阿里云 Google 镜像和华为 Maven 镜像；`google()`、`mavenCentral()` 与 `gradlePluginPortal()` 保留在镜像之后作为官方兜底源。
- `android/key.properties` 与 release keystore 均为本机敏感文件，已忽略，不能提交或分享。
- release 签名路径从 Android 项目根目录解析，当前本机配置可使用仓库根目录 `android-signing/starx-car-release.jks` 构建；APK 证书 SHA-1 为 `4C:83:43:EE:4B:E8:5E:0B:89:7A:29:E9:83:D8:17:C1:9A:0C:BF:73`，须在高德控制台登记到乘客端 Key。
- 当前本机 debug APK 证书 SHA-1 为 `1C:50:46:29:AE:A7:92:22:36:9C:CB:83:B7:E7:53:D1:1B:AE:D8:28`；若出现高德 `INVALID_USER_SCODE`，先确认乘客端 Key 的 Android 包名为本行 application ID，并同时登记实际构建签名的 SHA-1。
- 若日志中的 `SHA1Package` 与上述 debug SHA-1/包名一致，却同时出现 `SERVICE_NOT_EXIST` 与 `INSUFFICIENT_ABROAD_PRIVILEGES`，应先确认运行包已使用当前 6.x 定位 SDK，而不是继续修改 SHA-1。美国运营商环境的 x86_64 模拟器仍可能打印一条非阻断的内部鉴权日志；验收标准是页面不显示 Key 错误遮罩、地图出现当前位置且上车点成功选中。

```powershell
cd starx_car_passenger
fvm flutter pub get
fvm flutter analyze
fvm flutter test
fvm flutter run
# 或生成 debug APK
fvm flutter build apk --debug
# 连接 Android 真机后运行启动级集成测试
fvm flutter test integration_test/app_start_test.dart
```

本次排查确认本机 Key 已注入，运行 APK 上报的 debug SHA-1 和包名与高德控制台填写值一致。Android 清单已补齐地图/定位网络权限，内置地图插件也不再在地图加载完成时人为触发空数组异常；定位 SDK 已从 5.6.0 升级到仍支持 x86_64 模拟器的 6.5.1。已在 `Pixel 9 Pro (Android 16/API 36)` 美国运营商模拟器复测：Key 错误遮罩消失、当前位置蓝点可见且上车点成功选中；模拟器仍会打印一条不影响坐标返回的 `SERVICE_NOT_EXIST` 内部日志。

若出现“older Android embedding”并提示缺少 `android/AndroidManifest.xml`，说明使用了系统全局 Flutter。请在本模块目录执行 `fvm flutter ...`；本工程已使用 Android embedding v2，不能通过新增根级 Manifest 修复该提示。

地图挂载验收命令：`fvm flutter test integration_test/amap_map_test.dart -d <android-device>`。一次性定位验收命令：`fvm flutter test integration_test/amap_location_test.dart -d <android-device>`。两项测试均应在已配置 `android/amap.properties`、授予定位权限且可访问高德服务的 Android 环境执行。

登录错误回归：`fvm flutter test --dart-define=API_BASE_URL=http://127.0.0.1:1/api integration_test/auth_error_test.dart -d <android-device>`。

## 尚未实现

- 地点名称自动补全和搜索结果分页。
- 更细粒度的后台恢复提示和真机定位权限引导。
- 系统离线推送通知。

## WebSocket 与重新定位

详情订阅 `order.detail`，接驾地图订阅 `order.location`，服务中地图订阅 `order.route`，收到快照后更新原有模型、地图与路线。终态停止详情监听，页面释放时取消订阅，切换登录时销毁旧连接，重连后恢复订阅并取得最新状态。行程列表响应订单变化/重连通知刷新；位置停止上报后仍接收 stale 标记，显示最后已知位置。

行程列表查询期间收到的多个通知合并为一次后续刷新，在途请求继续完成。

订单离开服务中或位置可见阶段时，路线/位置订阅正常结束，不再将“订单当前不可获取路线规划上下文”作为异常抛出。乘客端兼容旧后端返回的这两个主题的状态 409，其他主题或鉴权/服务错误仍显示错误。页面销毁时立即取消订阅，即使高德定位或路线规划仍未完成，也不继续接收该订单的位置事件；已完成的订单仍由详情订阅正常更新结算界面。

叫车页复用公共包的精确授权、高德近期最佳结果和缓存关闭策略。点击重新定位会更新当前自动上车点，修复地图已移动而上车点仍保留旧坐标的问题；初始自动定位仍尊重用户已经选择的地点。接驾路线在移动 50 米或 3 秒后、服务中路线在移动 50 米或 5 秒后的下一次位置推送中重规划；失败时等待后续位置事件重试，不再定时查询位置。
