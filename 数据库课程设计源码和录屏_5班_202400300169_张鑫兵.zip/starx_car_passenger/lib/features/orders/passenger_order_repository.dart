import 'package:starx_car_common/starx_car_common.dart';

/// Passenger-only access to immediate order and trip endpoints.
///
/// This repository deliberately contains no polling timer or page state; those
/// belong to the passenger order/trip controllers so their lifecycle can be
/// stopped when a page is hidden or the app enters the background.
class PassengerOrderRepository {
  const PassengerOrderRepository(this._api);

  final ApiClient _api;

  Future<OrderQuote> quote({
    required Place pickup,
    required Place destination,
    OrderType orderType = OrderType.instant,
    DateTime? scheduledPickupTime,
    CancelToken? cancelToken,
  }) async => OrderQuote.fromJson(
    await _api.post(
          '/orders/quote',
          data: _orderBody(
            pickup: pickup,
            destination: destination,
            orderType: orderType,
            scheduledPickupTime: scheduledPickupTime,
          ),
          cancelToken: cancelToken,
        )
        as Map<String, dynamic>,
  );

  Future<OrderCreated> create({
    required Place pickup,
    required Place destination,
    OrderType orderType = OrderType.instant,
    DateTime? scheduledPickupTime,
    CancelToken? cancelToken,
  }) async => OrderCreated.fromJson(
    await _api.post(
          '/orders',
          data: _orderBody(
            pickup: pickup,
            destination: destination,
            orderType: orderType,
            scheduledPickupTime: scheduledPickupTime,
          ),
          cancelToken: cancelToken,
        )
        as Map<String, dynamic>,
  );

  Map<String, dynamic> _orderBody({
    required Place pickup,
    required Place destination,
    required OrderType orderType,
    required DateTime? scheduledPickupTime,
  }) => {
    'pickup': pickup.toJson(),
    'destination': destination.toJson(),
    if (orderType != OrderType.instant) 'orderType': orderTypeToJson(orderType),
    if (orderType == OrderType.scheduled && scheduledPickupTime != null)
      'scheduledPickupTime': _serverTime(scheduledPickupTime),
  };

  static String _serverTime(DateTime value) {
    String two(int n) => n.toString().padLeft(2, '0');
    return '${value.year}-${two(value.month)}-${two(value.day)} '
        '${two(value.hour)}:${two(value.minute)}:${two(value.second)}';
  }

  Future<OrderPage> list({
    int page = 1,
    int size = 20,
    OrderStatus? status,
    CancelToken? cancelToken,
  }) async {
    final query = <String, dynamic>{'page': page, 'size': size};
    if (status != null && status != OrderStatus.unknown) {
      query['status'] = orderStatusToJson(status);
    }
    final data = await _api.get(
      '/passengers/me/orders',
      queryParameters: query,
      cancelToken: cancelToken,
    );
    return OrderPage.fromJson(data as Map<String, dynamic>);
  }

  Future<OrderDetail> detail(
    String orderNo, {
    CancelToken? cancelToken,
  }) async => OrderDetail.fromJson(
    await _api.get('/orders/$orderNo', cancelToken: cancelToken)
        as Map<String, dynamic>,
  );

  Future<void> cancel(String orderNo, {String? reason}) async => _api.post(
    '/orders/$orderNo/cancel',
    data: reason == null || reason.trim().isEmpty
        ? null
        : {'reason': reason.trim()},
  );

  Future<PassengerComplaint> createComplaint(
    String orderNo, {
    required String complaintType,
    required String content,
  }) async => PassengerComplaint.fromJson(
    await _api.post(
          '/orders/$orderNo/complaints',
          data: {
            'complaintType': complaintType.trim(),
            'content': content.trim(),
          },
        )
        as Map<String, dynamic>,
  );

  Future<PassengerComplaintPage> myComplaints({
    int page = 1,
    int size = 20,
    CancelToken? cancelToken,
  }) async => PassengerComplaintPage.fromJson(
    await _api.get(
          '/complaints/me',
          queryParameters: {'page': page, 'size': size},
          cancelToken: cancelToken,
        )
        as Map<String, dynamic>,
  );

  Future<OrderTerminationResult> terminate(
    String orderNo, {
    required String reasonCode,
    String? reasonDetail,
  }) async => OrderTerminationResult.fromJson(
    await _api.post(
          '/orders/$orderNo/terminate',
          data: {
            'reasonCode': reasonCode,
            if (reasonDetail != null && reasonDetail.trim().isNotEmpty)
              'reasonDetail': reasonDetail.trim(),
          },
        )
        as Map<String, dynamic>,
  );

  Future<DriverLocation> driverLocation(
    String orderNo, {
    CancelToken? cancelToken,
  }) async => DriverLocation.fromJson(
    await _api.get('/orders/$orderNo/driver-location', cancelToken: cancelToken)
        as Map<String, dynamic>,
  );

  Future<RouteContext> routeContext(
    String orderNo, {
    CancelToken? cancelToken,
  }) async => RouteContext.fromJson(
    await _api.get('/orders/$orderNo/route-context', cancelToken: cancelToken)
        as Map<String, dynamic>,
  );

  Future<OrderRating> rating(
    String orderNo, {
    CancelToken? cancelToken,
  }) async => OrderRating.fromJson(
    await _api.get('/orders/$orderNo/rating', cancelToken: cancelToken)
        as Map<String, dynamic>,
  );

  Future<OrderRating> submitRating(
    String orderNo, {
    required int rating,
    String? content,
  }) async => OrderRating.fromJson(
    await _api.post(
          '/orders/$orderNo/rating',
          data: {
            'rating': rating,
            if (content != null && content.trim().isNotEmpty)
              'content': content.trim(),
          },
        )
        as Map<String, dynamic>,
  );

  Future<RatingPage> myRatings({
    int page = 1,
    int size = 20,
    CancelToken? cancelToken,
  }) async => RatingPage.fromJson(
    await _api.get(
          '/passengers/me/ratings',
          queryParameters: {'page': page, 'size': size},
          cancelToken: cancelToken,
        )
        as Map<String, dynamic>,
  );
}

class OrderCreated {
  const OrderCreated({
    required this.orderNo,
    required this.status,
    required this.quote,
  });

  final String orderNo;
  final OrderStatus status;
  final OrderQuote quote;

  factory OrderCreated.fromJson(Map<String, dynamic> json) => OrderCreated(
    orderNo: json['orderNo'] as String,
    status: orderStatusFromJson(json['status']),
    quote: OrderQuote.fromJson(json['quote'] as Map<String, dynamic>),
  );
}

/// A passenger's rating of the driver for one completed order.
class OrderRating {
  const OrderRating({
    required this.rated,
    this.rating,
    this.content,
    this.createdAt,
  });

  final bool rated;
  final int? rating;
  final String? content;
  final DateTime? createdAt;

  factory OrderRating.fromJson(Map<String, dynamic> json) => OrderRating(
    rated: json['rated'] as bool? ?? false,
    rating: (json['rating'] as num?)?.toInt(),
    content: json['content'] as String?,
    createdAt: json['createdAt'] == null
        ? null
        : DateTime.tryParse(json['createdAt'].toString()),
  );
}

/// One submitted rating shown in the passenger's rating history.
class RatingSummary {
  const RatingSummary({
    required this.orderNo,
    this.rating,
    this.content,
    this.createdAt,
  });

  final String orderNo;
  final int? rating;
  final String? content;
  final DateTime? createdAt;

  factory RatingSummary.fromJson(Map<String, dynamic> json) => RatingSummary(
    orderNo: json['orderNo'] as String,
    rating: (json['rating'] as num?)?.toInt(),
    content: json['content'] as String?,
    createdAt: json['createdAt'] == null
        ? null
        : DateTime.tryParse(json['createdAt'].toString()),
  );
}

/// Paginated rating history returned by `/passengers/me/ratings`.
class RatingPage {
  const RatingPage({
    required this.page,
    required this.size,
    required this.total,
    required this.records,
  });

  final int page;
  final int size;
  final int total;
  final List<RatingSummary> records;

  factory RatingPage.fromJson(Map<String, dynamic> json) => RatingPage(
    page: (json['page'] as num).toInt(),
    size: (json['size'] as num).toInt(),
    total: (json['total'] as num).toInt(),
    records: ((json['records'] as List<dynamic>? ?? const [])
        .whereType<Map<String, dynamic>>()
        .map(RatingSummary.fromJson)
        .toList(growable: false)),
  );
}

/// One complaint submitted by the current passenger and its final resolution.
class PassengerComplaint {
  const PassengerComplaint({
    required this.complaintNo,
    required this.orderNo,
    required this.complaintType,
    required this.content,
    required this.status,
    required this.refundAmount,
    required this.createdTime,
    this.resolutionType,
    this.resolutionContent,
    this.resolvedTime,
  });

  final String complaintNo;
  final String orderNo;
  final String complaintType;
  final String content;
  final String status;
  final String? resolutionType;
  final String? resolutionContent;
  final String refundAmount;
  final DateTime? createdTime;
  final DateTime? resolvedTime;

  bool get resolved => status == 'RESOLVED';

  factory PassengerComplaint.fromJson(Map<String, dynamic> json) =>
      PassengerComplaint(
        complaintNo: json['complaintNo'] as String,
        orderNo: json['orderNo'] as String,
        complaintType: json['complaintType'] as String? ?? 'OTHER',
        content: json['content'] as String? ?? '',
        status: json['status'] as String? ?? 'OPEN',
        resolutionType: json['resolutionType'] as String?,
        resolutionContent: json['resolutionContent'] as String?,
        refundAmount: json['refundAmount']?.toString() ?? '0.00',
        createdTime: _complaintTime(json['createdTime']),
        resolvedTime: _complaintTime(json['resolvedTime']),
      );
}

class PassengerComplaintPage {
  const PassengerComplaintPage({
    required this.page,
    required this.size,
    required this.total,
    required this.records,
  });

  final int page;
  final int size;
  final int total;
  final List<PassengerComplaint> records;

  factory PassengerComplaintPage.fromJson(Map<String, dynamic> json) =>
      PassengerComplaintPage(
        page: (json['page'] as num).toInt(),
        size: (json['size'] as num).toInt(),
        total: (json['total'] as num).toInt(),
        records: (json['records'] as List<dynamic>? ?? const [])
            .whereType<Map<String, dynamic>>()
            .map(PassengerComplaint.fromJson)
            .toList(growable: false),
      );
}

DateTime? _complaintTime(Object? value) =>
    value == null ? null : DateTime.tryParse(value.toString());
